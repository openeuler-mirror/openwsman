# This is openwsman.rb
#

require 'openwsman/openwsman'
