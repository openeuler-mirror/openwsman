#!/usr/bin/perl

use lib '../../../build/bindings/perl';
use lib '..';
use lib '../.libs';

use openwsman;

